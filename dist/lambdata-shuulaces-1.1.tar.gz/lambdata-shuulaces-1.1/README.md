# jacob_lambdata

## Installation

<pip install -i https://test.pypi.org/simple/ lambdata-shuulaces>

## Usage 
With this package, you can analyze which columns contain a NaN value by having it return with "FALSE". However, the NaN's must first be converted to the string "NaN". To call upon it, use <isitnan(df)>.
You can also use this package to turn any column filled with a datetime format to split into three separate columns for month, day, and year. to call upon it, use <splitdate(df)>. 